package Controller;

public enum HttpServletRequest {
	;

	Object getRequestDispatcher(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	String getParameter(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	Object getSession() {
		// TODO Auto-generated method stub
		return null;
	}

}
