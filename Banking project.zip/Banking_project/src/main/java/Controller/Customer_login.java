package Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.Customer_Dao;
import Dto.Customer;
@WebServlet("/customerlogin")
public class Customer_login extends HttpServlet
{
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	
	
		String cid=req.getParameter("custid");
		int customerid=Integer.parseInt(cid);///convert string to int
		
		String password=req.getParameter("pwd");
		
		Customer_Dao customer_Dao=new Customer_Dao();
		Customer customer=customer_Dao.login(customerid);
		if(customer==null)
		{
			resp.getWriter().print("<h1>Enetered Invalid Customer Id</h1>");
			req.getRequestDispatcher("Home.html").include(req,resp);
		}
		else {
			if(customer.getPassword().equals(password))
			{
				resp.getWriter().print("<h1>Login Successful</h1>");
				///session tracking
				req.getSession().setAttribute("customer",customer);//it is used to to store the value in the key and value format
				req.getRequestDispatcher("Customer_home.html").include(req,resp);
			}
			else
			{
				resp.getWriter().print("<h1>Invalid password</h1>");
				req.getRequestDispatcher("Home.html").include(req,resp);
			}
		}
		
	}
	

}
