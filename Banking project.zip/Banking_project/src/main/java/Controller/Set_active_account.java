package Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Set_active_account extends HttpServlet{
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String acc_no=req.getParameter("acno");
		long acc_number=Long.parseLong(acc_no);
		
		
		req.getSession().setAttribute(acc_no, acc_no);
		req.getRequestDispatcher("AccountHome.html").include(req, resp);
	}

}
