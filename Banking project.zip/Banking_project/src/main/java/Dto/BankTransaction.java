package Dto;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BankTransaction {

	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	
	int tid;
	double deposit;
	double withdraw;
	LocalDateTime datetime;
	
	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public LocalDateTime getDatetime() {
		return datetime;
	}

	public void setDatetime(LocalDateTime datetime) {
		this.datetime = datetime;
	}

	public double getDeposit() {
		return deposit;
	}

	public double getWithdraw() {
		return withdraw;
	}

	public void setDeposit(double amount) {
		
		
	}

	public void setWithdraw(double amount) {
		
		
	}

	public void setBalance(double amount) {
		
		
	}

	

	public void setDateTime(LocalDateTime now) {
		// TODO Auto-generated method stub
		
	}

	

}
