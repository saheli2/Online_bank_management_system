package Dto;

import java.sql.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import org.hibernate.id.enhanced.InitialValueAwareOptimizer;


@Entity
public class Customer {
	@SequenceGenerator(initialValue = 12243434,allocationSize = 1,sequenceName= "custid" ,name="custid")
	@GeneratedValue(generator="custid")///here this is used to generate the id randomly
	
	@Id
	
	int cid;
	
	String cname;
	
	String password;
	
	
	long mob;
	
	String email;
	
	String gender;
	
	Date date;
	
	@OneToMany
	List<Bank_account>bankaccounts;

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getMob() {
		return mob;
	}

	public void setMob(long mob) {
		this.mob = mob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public List<Bank_account> getBankaccounts() {
		return bankaccounts;
	}

	public void setBankaccounts(List<Bank_account> bankaccounts) {
		this.bankaccounts = bankaccounts;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date2) {
		// TODO Auto-generated method stub
		
	}
}
